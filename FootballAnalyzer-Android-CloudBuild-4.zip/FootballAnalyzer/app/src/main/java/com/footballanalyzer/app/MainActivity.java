package com.footballanalyzer.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    int bg = Color.rgb(9,13,18), panel = Color.rgb(20,27,35), green = Color.rgb(56,217,130), muted = Color.rgb(157,171,185);
    LinearLayout root; EditText teams, league;
    int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    @Override public void onCreate(Bundle b) { super.onCreate(b); getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(bg); build(); }
    TextView text(String s, int size, int color, boolean bold) { TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); if(bold)t.setTypeface(null, Typeface.BOLD); return t; }
    GradientDrawableLike shape(int color) { return new GradientDrawableLike(color, dp(16)); }
    void addSpace(int h) { View v=new View(this); root.addView(v,new LinearLayout.LayoutParams(1,dp(h))); }
    void build() {
        ScrollView scroll=new ScrollView(this); scroll.setBackgroundColor(bg); root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(20),dp(28),dp(20),dp(24)); scroll.addView(root); setContentView(scroll);
        TextView ball=text("⚽",38,green,true); ball.setGravity(Gravity.CENTER); root.addView(ball,new LinearLayout.LayoutParams(-1,dp(54)));
        TextView title=text("FOOTBALL ANALYZER",24,Color.WHITE,true); title.setGravity(Gravity.CENTER); root.addView(title);
        TextView sub=text("MATCH STATISTICS • FOUR MARKETS",11,muted,true); sub.setGravity(Gravity.CENTER); root.addView(sub); addSpace(28);
        root.addView(text("ВВЕДИ МАТЧ",12,muted,true)); addSpace(8);
        teams=field("Например: Манчестер Сити — Брэдфорд"); root.addView(teams,new LinearLayout.LayoutParams(-1,dp(54))); addSpace(14);
        root.addView(text("ЛИГА",12,muted,true)); addSpace(8);
        league=field("Определить автоматически"); root.addView(league,new LinearLayout.LayoutParams(-1,dp(54))); addSpace(18);
        Button go=new Button(this); go.setText("АНАЛИЗИРОВАТЬ МАТЧ  →"); go.setTextColor(Color.rgb(5,20,12)); go.setTextSize(14); go.setTypeface(null,Typeface.BOLD); go.setBackground(shape(green)); root.addView(go,new LinearLayout.LayoutParams(-1,dp(56)));
        go.setOnClickListener(v->{ String m=teams.getText().toString().trim(); if(m.isEmpty()){teams.setError("Введи две команды");return;} new AlertDialogBuilder(this).show(); });
        addSpace(26); root.addView(text("ЧТО АНАЛИЗИРУЕМ",13,Color.WHITE,true)); addSpace(12);
        card("⚽  ГОЛЫ","Общий и индивидуальный тотал"); card("🚩  УГЛОВЫЕ","Общий и индивидуальный тотал"); card("🟨  ЖЁЛТЫЕ КАРТОЧКИ","Командные показатели и общий тотал"); card("🤝  ФОЛЫ","Общее количество и по командам");
        addSpace(18); TextView note=text("Важно: прогнозы появятся после подключения источника футбольной статистики и AI-сервера. Приложение не показывает выдуманные цифры.",12,muted,false); note.setGravity(Gravity.CENTER); root.addView(note);
    }
    EditText field(String hint){ EditText e=new EditText(this); e.setSingleLine(true); e.setTextSize(15); e.setTextColor(Color.WHITE); e.setHintTextColor(muted); e.setHint(hint); e.setPadding(dp(14),0,dp(14),0); e.setBackground(shape(panel)); return e; }
    void card(String a,String b){ LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(16),dp(13),dp(16),dp(13)); box.setBackground(shape(panel)); TextView h=text(a,15,Color.WHITE,true); box.addView(h); TextView d=text(b,12,muted,false); box.addView(d); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.bottomMargin=dp(9); root.addView(box,p); }
    class GradientDrawableLike extends android.graphics.drawable.GradientDrawable { GradientDrawableLike(int c,int r){setColor(c);setCornerRadius(r);} }
    class AlertDialogBuilder { Activity a; AlertDialogBuilder(Activity a){this.a=a;} void show(){ new android.app.AlertDialog.Builder(a).setTitle("Нужно подключить статистику").setMessage("Экран приложения готов. Чтобы выдавать реальные тоталы по голам, угловым, карточкам и фолам, требуется подключить API футбольной статистики и сервер анализа. Без них я не буду подставлять случайные прогнозы.").setPositiveButton("Понятно",(d,w)->{}).show(); } }
}
