package com.footballanalyzer.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.content.SharedPreferences;
import android.text.InputType;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends Activity {
    int bg=Color.rgb(9,13,18), panel=Color.rgb(20,27,35), green=Color.rgb(56,217,130), muted=Color.rgb(157,171,185);
    LinearLayout root; EditText teams, league;
    SharedPreferences prefs;
    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    @Override public void onCreate(Bundle b){super.onCreate(b); prefs=getSharedPreferences("football_analyzer",MODE_PRIVATE); getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(bg); build();}
    TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
    GradientDrawable shape(int c){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(dp(16));return d;}
    void space(int h){View v=new View(this);root.addView(v,new LinearLayout.LayoutParams(1,dp(h)));}
    void build(){
        ScrollView sc=new ScrollView(this);sc.setBackgroundColor(bg);root=new LinearLayout(this);root.setOrientation(1);root.setPadding(dp(20),dp(24),dp(20),dp(24));sc.addView(root);setContentView(sc);
        TextView ball=text("⚽",38,green,true);ball.setGravity(17);root.addView(ball,new LinearLayout.LayoutParams(-1,dp(52)));
        TextView title=text("FOOTBALL ANALYZER",24,Color.WHITE,true);title.setGravity(17);root.addView(title);
        TextView sub=text("MATCH STATISTICS • FOUR MARKETS",11,muted,true);sub.setGravity(17);root.addView(sub);space(20);
        Button settings=new Button(this);settings.setText("⚙ НАСТРОЙКИ API");settings.setOnClickListener(v->settingsDialog());root.addView(settings,new LinearLayout.LayoutParams(-1,dp(48)));space(18);
        root.addView(text("ВВЕДИ МАТЧ",12,muted,true));space(8);teams=field("Например: Манчестер Сити — Брэдфорд");root.addView(teams,new LinearLayout.LayoutParams(-1,dp(54)));space(12);
        root.addView(text("ЛИГА",12,muted,true));space(8);league=field("Определить автоматически");root.addView(league,new LinearLayout.LayoutParams(-1,dp(54)));space(16);
        Button go=new Button(this);go.setText("АНАЛИЗИРОВАТЬ МАТЧ  →");go.setTextColor(Color.rgb(5,20,12));go.setTypeface(null,Typeface.BOLD);go.setBackground(shape(green));root.addView(go,new LinearLayout.LayoutParams(-1,dp(56)));
        go.setOnClickListener(v->{if(teams.getText().toString().trim().isEmpty()){teams.setError("Введи две команды");return;} if(prefs.getString("api_key","").isEmpty()){settingsDialog();return;} new android.app.AlertDialog.Builder(this).setTitle("Следующий этап").setMessage("API-ключ сохранён. Сейчас проверим соединение с API-Football. Полный анализ матча будет добавлен следующим обновлением.").setPositiveButton("Понятно",null).show();});
        space(20);root.addView(text("ЧТО АНАЛИЗИРУЕМ",13,Color.WHITE,true));space(10);
        card("⚽ ГОЛЫ","Общий и индивидуальный тотал");card("🚩 УГЛОВЫЕ","Общий и индивидуальный тотал");card("🟨 ЖЁЛТЫЕ КАРТОЧКИ","Командные показатели и общий тотал");card("🤝 ФОЛЫ","Общее количество и по командам");
        space(12);TextView note=text("Сначала сохрани API-ключ в настройках. Не публикуй APK с личным ключом внутри.",12,muted,false);note.setGravity(17);root.addView(note);
    }
    EditText field(String hint){EditText e=new EditText(this);e.setSingleLine(true);e.setTextSize(15);e.setTextColor(Color.WHITE);e.setHintTextColor(muted);e.setHint(hint);e.setPadding(dp(14),0,dp(14),0);e.setBackground(shape(panel));return e;}
    void card(String a,String b){LinearLayout box=new LinearLayout(this);box.setOrientation(1);box.setPadding(dp(16),dp(13),dp(16),dp(13));box.setBackground(shape(panel));box.addView(text(a,15,Color.WHITE,true));box.addView(text(b,12,muted,false));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(9);root.addView(box,p);}
    void settingsDialog(){
        EditText key=new EditText(this);key.setSingleLine(true);key.setText(prefs.getString("api_key",""));key.setHint("Вставь API-ключ сюда");key.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        LinearLayout box=new LinearLayout(this);box.setPadding(dp(20),dp(8),dp(20),0);box.addView(key,new LinearLayout.LayoutParams(-1,dp(54)));
        new android.app.AlertDialog.Builder(this).setTitle("Настройки API-Football").setMessage("Вставь свой API-ключ. Он сохранится только на этом телефоне. Не отправляй APK с этим ключом другим людям.").setView(box)
        .setPositiveButton("СОХРАНИТЬ",(d,w)->{String value=key.getText().toString().trim();if(!value.isEmpty()){prefs.edit().putString("api_key",value).apply();Toast.makeText(this,"API-ключ сохранён на телефоне",Toast.LENGTH_LONG).show();}})
        .setNegativeButton("ОТМЕНА",null).setNeutralButton("ПРОВЕРИТЬ",(d,w)->{String value=key.getText().toString().trim();if(!value.isEmpty())checkApi(value);}).show();
    }
    void checkApi(String key){
        Toast.makeText(this,"Проверяем API…",Toast.LENGTH_SHORT).show();
        new Thread(()->{HttpURLConnection c=null;String message;try{URL u=new URL("https://v3.football.api-sports.io/status");c=(HttpURLConnection)u.openConnection();c.setRequestMethod("GET");c.setRequestProperty("x-apisports-key",key);c.setConnectTimeout(12000);c.setReadTimeout(12000);int code=c.getResponseCode();message=code==200?"Ключ принят. Соединение с API работает.":"Сервер ответил кодом "+code+". Проверь ключ и тариф."; }catch(Exception e){message="Не удалось подключиться: "+e.getMessage();}finally{if(c!=null)c.disconnect();}final String result=message;runOnUiThread(()->new android.app.AlertDialog.Builder(this).setTitle("Проверка API").setMessage(result).setPositiveButton("OK",null).show());}).start();
    }
}
